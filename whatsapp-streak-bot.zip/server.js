const express = require("express");
const QRCode = require("qrcode");
const { Client, LocalAuth } = require("whatsapp-web.js");

const app = express();
app.use(express.json());
app.use(express.static("public"));

let latestQR = null;
let connected = false;
let botEnabled = true;
let activeGroups = new Set();
const replies = [
  "يا شيخ لا تتكلم واجد 😭",
  "صور ستريك وبس 📸",
  "يا ابوي لا ترسل مرتين 😂",
  "استمر ستريكك جامد اليوم 🔥"
];

// userId -> { streak, lastDate }
const users = new Map();

const client = new Client({
  authStrategy: new LocalAuth({ clientId: "streak-bot" }),
  puppeteer: { headless: true, args: ["--no-sandbox", "--disable-setuid-sandbox"] }
});

client.on("qr", async qr => {
  latestQR = await QRCode.toDataURL(qr);
  connected = false;
});

client.on("ready", () => {
  connected = true;
  latestQR = null;
  console.log("WhatsApp bot is ready.");
});

client.on("disconnected", reason => {
  connected = false;
  console.log("Disconnected:", reason);
});

function today() {
  return new Date().toISOString().slice(0, 10);
}

client.on("message", async msg => {
  if (!botEnabled) return;

  const chat = await msg.getChat();
  if (!chat.isGroup) return;
  if (activeGroups.size && !activeGroups.has(chat.id._serialized)) return;

  const sender = msg.author || msg.from;
  const text = (msg.body || "").trim();

  if (msg.hasMedia && msg.type === "image") {
    const old = users.get(sender) || { streak: 0, lastDate: null };
    const t = today();

    // Only ONE image per user per day counts.
    if (old.lastDate === t) {
      await msg.reply("يا ابوي خلاص حسبناها اليوم 😂📸");
      return;
    }

    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    old.streak = old.lastDate === yesterday ? old.streak + 1 : 1;
    old.lastDate = t;
    users.set(sender, old);

    await msg.reply(`🔥 ستريكك صار ${old.streak} يوم`);
    return;
  }

  if (/^(كم|كم عندي|كم ستريكه|كم ستريكي)$/i.test(text)) {
    const u = users.get(sender);
    await msg.reply(`🔥 ستريكك: ${u?.streak || 0} يوم`);
    return;
  }

  if (text) {
    const reply = replies[Math.floor(Math.random() * replies.length)];
    await msg.reply(reply);
  }
});

app.get("/api/status", (req, res) =>
  res.json({ connected, botEnabled, groups: [...activeGroups], replies })
);

app.get("/api/qr", (req, res) => res.json({ qr: latestQR }));

app.post("/api/toggle", (req, res) => {
  botEnabled = !!req.body.enabled;
  res.json({ botEnabled });
});

app.post("/api/replies", (req, res) => {
  if (typeof req.body.text === "string" && req.body.text.trim())
    replies.push(req.body.text.trim());
  res.json({ replies });
});

app.delete("/api/replies/:index", (req, res) => {
  const i = Number(req.params.index);
  if (Number.isInteger(i) && i >= 0 && i < replies.length) replies.splice(i, 1);
  res.json({ replies });
});

app.get("/api/groups", async (req, res) => {
  if (!connected) return res.json([]);
  const chats = await client.getChats();
  res.json(chats.filter(c => c.isGroup).map(c => ({
    id: c.id._serialized, name: c.name, enabled: activeGroups.has(c.id._serialized)
  })));
});

app.post("/api/groups/toggle", (req, res) => {
  const id = req.body.id;
  if (!id) return res.status(400).json({ error: "missing id" });
  activeGroups.has(id) ? activeGroups.delete(id) : activeGroups.add(id);
  res.json({ groups: [...activeGroups] });
});

app.get("/api/leaderboard", (req, res) => {
  const list = [...users.entries()]
    .map(([id, u]) => ({ id, streak: u.streak }))
    .sort((a,b) => b.streak - a.streak);
  res.json(list);
});

client.initialize();

app.listen(process.env.PORT || 3000, () =>
  console.log("Dashboard running on port " + (process.env.PORT || 3000))
);
